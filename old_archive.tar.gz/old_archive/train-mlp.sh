#!/bin/bash -l
module load neon
python ./dayabay_autoencoder.py --epochs 100
python ./tsne-visualize.py

