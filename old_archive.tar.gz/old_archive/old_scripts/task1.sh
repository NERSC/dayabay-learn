#!/bin/sh
echo "my taskid is: " $TF_TASKID 

./intel_autoencode.sh /scratch3/scratchdirs/jialin/dayabay/preprocess/output-fla/$TF_TASKID.h5  $SCRATCH/intel_data --intel

