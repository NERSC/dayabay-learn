#!/usr/bin/env bash
#usage intel_autoencode.sh h5file-name savedir-name --intel
if [ "$#" -lt 2 ]
then
echo "Too few arguments! Usage: intel_autoencode.sh h5file-name savedir-name --intel"
exit
fi

h5file=$1
echo h5:$h5file
savedir=$2
echo sd:$savedir
intel=$3
. neon2.profile
#echo $h5file
new_dirname="$(basename "$(dirname "$h5file")")"
filename=`basename $h5file`
base_name=${filename%.*}
class=`python ./get_class.py $h5file`
echo $class
name=$base_name"-$class".h5
cp $h5file $savedir/$name
tmpdir=$savedir/${name%.*}
mkdir $tmpdir
python predict.py --h5file $savedir/$name --save_dir $tmpdir --all_train $intel
#b/c split files writes to ./ for now
rm $savedir/$name

PKL=$savedir/pkls/${name%.*}.pkl
echo $PKL
mv $tmpdir/train-inference.pkl $PKL
rm -rf $tmpdir
final_dir=/scratch3/scratchdirs/jialin/dayabay/autoencoded/$new_dirname
if [ ! -d $final_dir ]; then
mkdir $final_dir
fix_perms -g dasrepo $final_dir/..
fi
#dont need to move the train targets so keep saving over them
#mv $savedir/train-targets.pkl $savedir/targets_$name.pkl
#done
#add column for each class and combine thesei files
python ./numpy_pkl_to_h5.py $final_dir  $PKL

#remove the pkls
rm $PKL 
