#!/bin/sh
echo "my taskid is: " $TF_TASKID 

./intel_autoencode.sh ./data/jialin_small_files/$TF_TASKID.h5 $SCRATCH/intel_data --intel

