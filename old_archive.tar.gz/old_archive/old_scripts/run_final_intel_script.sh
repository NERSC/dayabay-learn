#!/usr/bin/env bash

for i in 1 2 3
do
qsub -F "$i" ./intel_ae_tf.pbs
done
