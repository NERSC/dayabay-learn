#!/bin/sh

h5dir=/scratch3/scratchdirs/jialin/dayabay/preprocess/output-muo 
for h5file in `ls $h5dir`
do
echo $h5dir/$h5file
./extras_intel_autoencode.sh $h5dir/$h5file $SCRATCH/intel_data --intel
done


