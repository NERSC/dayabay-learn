#!/bin/sh
echo "my taskid is: " $TF_TASKID 
cd /global/homes/r/racah/projects/dayabay-learn
h5dir=/scratch3/scratchdirs/jialin/dayabay/preprocess/output-oth
h5file=`ls $h5dir | sed -n "$TF_TASKID"p`
./extras_intel_autoencode.sh $h5dir/$h5file  $SCRATCH/intel_data --intel /scratch3/scratchdirs/jialin/dayabay/autoencoded

