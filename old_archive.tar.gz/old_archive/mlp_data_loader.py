from peter_old_code.dayabay_dataset_code import dayabay_rotate as dbr
import h5py
#from sklearn.preprocessing import StandardScaler
import numpy as np
import pickle
import glob
import os
from os.path import join

from operator import mul
#todo rotate/center data
def load_dayabaysingle(path,
                       validation=True
                       ,
                       cross_validate=False
                       ,
                       normalize=True
                       ,
                       just_test=False
                       ,
                       test_prop=0.2
                       ,
                       val_prop=0.2
                       ,
                       seed=3):

    '''val_prop is proprotion of train that is val
    test_prop is proportion of total that is test'''
    pkl_dir = './pkled_standard_scaler'
    h5_dataset = h5py.File(path)
    X = np.asarray(h5_dataset['inputs']).astype('float64')
    y = np.asarray(h5_dataset['targets']).astype('float64')
    nclass = 5

    #filter out zero rows
    X,y = filter_out_zeros(X,y)


    #cetner the highest sensor value X
    X = dbr.rotate_tr(X, dbr.get_rot_amount_maxelem_tr(X))







    if not just_test:
        X_train, y_train, X_test, y_test, num_tr = \
            split_train_test(X,y,nclass, test_prop, seed)




        if validation:
            X_train, y_train, X_val, y_val = \
                split_train_val(X_train, y_train, seed, val_prop, num_tr)

        if normalize:
            #mean center data
            tr_mean = np.mean(X_train)
            tr_std = np.std(X_train)


            if not os.path.exists(pkl_dir):
                os.mkdir(pkl_dir)
            pickle.dump(tr_mean, open(join(pkl_dir, str(num_tr) + '.pkl'), 'w'))
            X_train -= tr_mean
            X_train /= tr_std
            X_test -= tr_mean
            X_test /= tr_std
            if validation:
                X_val -= tr_mean
                X_val /= tr_std

    else:
        # X_test = np.vstack(X_eq_cl)
        # y_test = np.vstack(y_eq_cl)
        #
        # if normalize:
        #     # assert os.path.exists(pkl_dir), "No standard scaler pkl files exist. Exiting!"
        #     # #upload standard scaler that was fit on training data and transform test based on that
        #     # newest_file = max(glob.iglob(join(pkl_dir,'*.pkl')), key=os.path.getctime)
        #     # ss = pickle.load(open(join(pkl_dir,newest_file)))
        #     # X_test = ss.transform(X_test)
        #     pass
        pass






    if validation:
        ret = [(X_train, y_train), (X_val, y_val), (X_test, y_test), nclass]

    elif cross_validate:
        pass
    else:
        ret = [(X_train, y_train), (X_test, y_test), nclass]

    return ret
